# Synteza recenzji ARS-Codex

**Rekomendacja: Minor Revision — ograniczone poprawki metod, interpretacji i prezentacji.**

Recenzowano wersję *Information Leakage from Token-Length Traces in Streaming LLMs: Cross-Model Reconstruction and Defense Evaluation* z 1 listopada 2026 r., 21 stron. Cel autora: **Electronics / Artificial Intelligence / Special Issue „Trustworthy AI for Large Models and Security Systems” / Article**. Podstawą są zamrożone kopie w `inputs/`; TEX SHA-256 `8539201fa3c7aeb62d219037c3395a083e541b4fc08df1f1b701327c8ca42dc5`.

Artykuł ma uzasadniony wkład empiryczny: pokazuje, jak walidacja śladu, renderowanie referencji i przetwarzanie wejścia zmieniają ocenę ustalonego rekonstruktora. Niezależne od wcześniejszych etykiet PASS rachunki na zapisach potwierdziły φ dla wszystkich 6600 rekonstrukcji, decyzje testów oraz dopasowane porównanie 600 renderowań. Ujawniono przy tym nowy problem selektora kandydatów. Poprawność zapisanych średnich nie rozstrzyga jego wpływu na wyniki uzyskiwane przez inaczej zaimplementowany ranking.

Rekomendacja jest warunkowa wobec **obecnego, ograniczonego celu oceny konkretnej implementacji**. Nie oznacza potwierdzenia poprawnego rankingu prawdopodobieństwa zakończonych sekwencji, praktycznego ataku na TLS ani bezpieczeństwa obron. Brak danych o wpływie błędu rankingu nie jest traktowany jako dowód jego obojętności.

## Stanowiska panelu

| Rola | Rekomendacja w swoim zakresie | Ustalenia |
|---|---|---|
| EIC — wkład i prezentacja | Minor Revision | Tytuł, wspólna mapa protokołów; identyfikacja pakietu jako uwaga doradcza |
| R1 — metodologia | Minor Revision | PAD po EOS w rankingu, szczegóły lokalnego MAP, przepisy ziaren bootstrapu |
| R2 — dziedzina i literatura | Minor Revision | Stałe wejście `pad_32`, jednostka i miara wyników Weissa, domena treningu rekonstruktora |
| R3 — znaczenie praktyczne | Accept w zakresie R3 | Ograniczenia obserwacji, kosztów i miar są adekwatnie ujawnione; brak wymaganych nowych badań |
| DA — krytyka argumentu | Bez Critical/Major; jedna uwaga Minor | Osobne potwierdzenie stałego wejścia `pad_32/frozen` |

Rekomendacja wynika z charakteru konkretnych ustaleń, bez sumowania punktów. R3 nie oceniał szczegółowej statystyki ani selektora kandydatów; jego brak zastrzeżeń nie stanowi sprzeciwu wobec R1. Podobnie niewymienienie błędu rankingu przez inne role nie jest jego odrzuceniem. Żadne stanowisko nie zgłosiło Critical wymagającego dodatkowego rozstrzygnięcia.

## Poprawki metodologiczne i interpretacyjne

### Selekcja kandydatów i granica EOS — R1-W1

W §3.5 opisano wybór przez sumę logarytmów prawdopodobieństw przejść. Kod `weiss_reconstruction.py:271–285` sumuje cały wiersz `compute_transition_scores`, co w przypiętej wersji Transformers może obejmować wymuszone PAD po EOS krótszego kandydata. Test na gotowych tensorach odwrócił ranking: kandydat z sumą do EOS −0,009890 otrzymał sumę −∞ i przegrał z kandydatem −4,394449. Test nie używał wag ani inferencji.

**Co wiadomo:** mechanizm i możliwość odwrócenia rankingu są potwierdzone. **Czego nie wiadomo:** częstość i wielkość wpływu w kampanii; zapisano wybrane predykcje, bez ID i score wszystkich kandydatów. MAP z jednym kandydatem nie wykonuje takiego wyboru.

Minimalna naprawa przy zachowaniu obecnego celu polega na dokładnym opisaniu rzeczywiście użytej reguły, jej ograniczenia i nieustalonego wpływu. Wyniki muszą nadal odnosić się do tej konkretnej wersji. Jeśli autorzy chcą przedstawiać je jako wyniki selekcji według prawdopodobieństwa sekwencji zakończonej EOS, potrzebny jest **ograniczony audyt inferencji zapisujący wszystkich kandydatów i oba rankingi**. Dopiero jego wynik pozwoli określić konieczność i zakres ponownych obliczeń. Synteza nie zakłada ani zerowego wpływu, ani konieczności bezwarunkowego powtórzenia całej kampanii.

Zachowuję klasyfikację Minor z R1: dane nadal opisują wykonaną implementację, a manuskrypt nie dowodzi optymalności selektora. Wzmocnienie twierdzeń na poprawiony algorytm wymaga nowego dowodu i może zmienić zakres rewizji.

### Stałe wejście `pad_32` — R2-W1 i DA-N1

Należy rozdzielić pełną obserwację długości `Z` od wejścia zachowanego przez enkoder `E(Z)`. Audyty wykazały identyczne wejścia w każdym z badanych podzbiorów `pad_32`: 60 rekordów pilotażu oraz 600 rekordów frozen/adaptive MAP. W zamrożonym MAP dodatkowo wszystkie 150 par między modelami przy wspólnym seedzie dają tę samą predykcję.

W tych warunkach dekoder nie korzysta z różnic długości śladu, które zniknęły po obcięciu. Dodatni φ pokazuje pokrywanie się wygenerowanego tekstu z referencją przy stałym wejściu. Ogólne stwierdzenie, że pełny kanał zachowuje długość, pozostaje prawdziwe dla obserwatora całego `Z`, lecz nie wyjaśnia tego konkretnego wyniku T5. Poprawić §4.6–4.7 i §5.3, korzystając z już zapisanych danych; nowa inferencja nie jest potrzebna.

R2 rozszerza audyt na warunki adaptive; DA niezależnie opracował węższy dowód dla frozen. To uzupełniające zakresy, nie sprzeczność. Kilka numerów podsekcji w raporcie DA ma przesunięcie o jeden; cytowane wiersze i treść są identyfikowalne, a poprawne lokalizacje zapisano w `validation/locator_notes.json`.

### Specyfikacja MAP i bootstrapu — R1-W2, R1-W3

Termin „empirical MAP inverse” wymaga opisu lokalnej dominanty długości/krotki, obsługi niewidzianych obserwacji, priory, remisów oraz heurystyki ostatniej grupy. Kod zawiera również 16 realizacji losowego paddingu na ślad kalibracyjny i reguły awaryjne. Zwięzły pseudokod lub dodatek wystarczy do odtworzenia rzeczywiście użytej procedury; nie należy sugerować globalnego MAP całej sekwencji.

Oddzielnie trzeba ograniczyć opis ziarna `20260706` do właściwych analiz. Przedziały pilotów i MAP mają osobne ziarna BLAKE2s dla komórek i kontrastów. Tabele są zgodne z faktycznym przepisem; problem dotyczy możliwości ich odtworzenia wyłącznie na podstawie obecnego opisu.

### Kontekst literatury i transferu — R2-W2, R2-W3

Przy 27% i około 53% z pracy Weissa wskazać **pierwsze segmenty i kosinus embeddingów**. Obecny kosinus częstości słów i LR@0.5 mają inną definicję i zakres referencji; liczby nie są bezpośrednio porównywalne.

Opisać źródłową domenę uczenia przedstawioną przez Weissa, w tym UltraChat, oraz zakres udokumentowanego związku użytych checkpointów z tą procedurą. Wskazać różnicę między długościami znakowymi w źródłowej pracy a bieżącymi bajtami UTF-8. Nie poświadczać nieznanej historii wag ani nie wywodzić z tej różnicy niezmierzonego wpływu.

R2 odczytał publiczne oryginały Weissa, Li i *Whisper Leak*. Drobna korekta bibliograficzna dotyczy Li: istnieje opublikowana wersja USENIX 2026, tytuł *From Length to Content: Token-Length Side-Channel Attacks on LLM API Merged Outputs*, s. 2187–2206. To aktualizacja metadanych, nie zakwestionowanie oparcia cytowanego twierdzenia.

## Prezentacja i dostęp do materiałów

**EIC-W1:** zawęzić tytuł do faktycznego pomiaru rekonstrukcji w instrumentowanym środowisku. Jest to uwaga o komunikacji zakresu; tekst i abstrakt już zawierają właściwe ograniczenia.

**EIC-W2:** zebrać protokoły w jednym zestawieniu: kohorta/referencja, liczebność, budżet 96/512, zakres segmentów, kandydaci, ziarna i odpowiadające tabele. Ma to wyjaśnić, dlaczego baseline różnych eksperymentów nie są zamienne. Nie wymaga wyrównania zakresów przez nowe obliczenia.

**EIC-W3 — doradcze:** wskazać zamrożoną wersję pakietu i drogę dostępu do niej. Do recenzji może wystarczyć kontrolowany dostęp do konkretnego suplementu; publiczna publikacja nie musi jej poprzedzać. Nie uznajemy lokalnych plików za nieistniejące ani nie twierdzimy, że naruszono zasady MDPI. W tej sesji nie opublikowano danych.

## Co nie jest obowiązkowym rozszerzeniem tej rewizji

Ocena ujawnienia semantycznego, pozyskanie śladu z TLS, pomiar opóźnienia, scenariuszowo rozłączny trening/test i dostrajanie T5 na obronach byłyby osobnymi, silniejszymi badaniami. Aktualny tekst odpowiednio ogranicza twierdzenia; panel nie ustanawia ich automatycznie warunkiem zamknięcia wskazanych uwag. Ograniczony audyt selektora z R1-W1 dotyczy innej kwestii: zgodności wyniku z wybraną definicją ocenianego algorytmu.

## Pochodzenie i granice rekomendacji

Jest to symulowana recenzja ARS-Codex, `NOT_CALIBRATED`, w trybie pełnym bez kontraktu sprintowego. Pięć ról pracowało w osobnych kontekstach, bez przekazywania wzajemnych raportów przed ich zamknięciem. Wszystkie korzystały z tej samej rodziny modeli i dostawcy. Syntezę wykonał orkiestrator posiadający historię wcześniejszej redakcji manuskryptu. To ograniczenie ujawniono; rozdzielenie ról nie dowodzi niezależności błędów i nie zastępuje zewnętrznych recenzentów.

| Oś pochodzenia | Ustalenie |
|---|---|
| Rozdzielenie ról | Tak, pięć odrębnych zadań |
| Rozdzielenie kontekstów | Tak, w obrębie tej próby panelu |
| Widoczność ocen innych ról przed zamknięciem | Nie przekazano; stanowiska potwierdziły brak odczytu |
| Różne rodziny modeli | Nie, jedna rodzina GPT-6 |
| Różni dostawcy | Nie, OpenAI |
| Różni odpowiedzialni recenzenci ludzcy | Nie, recenzja modelowa |

Dokładne bieżące wymagania Electronics/Special Issue pozostają niezweryfikowane: oficjalne strony MDPI zwróciły HTTP 403. Nie wywodzimy z braku dostępu niezgodności manuskryptu. Kontrola literatury obejmuje trzy najbliższe prace, a nie poświadczenie wszystkich pozycji bibliografii. Recenzja nie zmieniła artykułu, kodu ani danych i nie uruchamiała nowych generacji modeli.


Kontrola skrótów poniżej jest dodatkiem automatycznym wykonanym po ustaleniu rekomendacji. Wejściem był tekst wyekstrahowany z PDF; pokrycie jest częściowe, a wykrycia obejmują także metadane, symbole i bibliografię. Nie zmieniają decyzji i wymagają interpretacji redakcyjnej.

## Attachment: Acronym Check (advisory, #849)

### Acronym check (advisory; no reply needed)
Coverage: body (partial)
Not in this input: English abstract, Chinese abstract.
Not checked:
- Body, line 43: MAP (the initials before its parentheses do not spell it)
- Body, line 61: SSE (the initials before its parentheses do not spell it)
- Body, line 79: TLS (the initials before its parentheses do not spell it)

| Scope | Line | Rule | Acronym | Uses |
|---|---|---|---|---|
| Body | 8 | Not defined | BY | 1 |
| Body | 8 | Not defined | CC | 1 |
| Body | 11 | Defined after first use | LLM | 6 |
| Body | 31 | Not defined | ID | 14 |
| Body | 59 | Defined again | LLM | 6 |
| Body | 71 | Not defined | UTF | 4 |
| Body | 77 | Not defined | HTTP | 3 |
| Body | 108 | Not defined | RQ1 | 1 |
| Body | 113 | Not defined | RQ2 | 1 |
| Body | 120 | Not defined | RQ3 | 1 |
| Body | 143 | Not defined | LLeakM | 3 |
| Body | 173 | Not defined | AI | 4 |
| Body | 177 | Not defined | API | 2 |
| Body | 197 | Not defined | ROUGE | 6 |
| Body | 217 | Not defined | QUIC | 2 |
| Body | 235 | Not defined | LT | 1 |
| Body | 318 | Not defined | DONE | 2 |
| Body | 378 | Not defined | ASCII | 3 |
| Body | 522 | Not defined | KV | 1 |
| Body | 524 | Not defined | EOS | 19 |
| Body | 546 | Not defined | CUDA | 1 |
| Body | 550 | Not defined | CPU | 1 |
| Body | 552 | Not defined | GB | 1 |
| Body | 552 | Not defined | GPU | 1 |
| Body | 552 | Not defined | NVIDIA | 1 |
| Body | 552 | Not defined | RTX | 1 |
| Body | 552 | Not defined | VRAM | 1 |
| Body | 664 | Not defined | LR | 13 |
| Body | 802 | Not defined | BLAKE2 | 2 |
| Body | 1063 | Not defined | RL | 2 |
| Body | 1239 | Not defined | nEOS | 1 |
| Body | 2165 | Not defined | USENIX | 9 |
| Body | 2170 | Not defined | DSS | 1 |
| Body | 2170 | Not defined | RSA | 1 |
| Body | 2172 | Not defined | CRYPTO | 1 |
| Body | 2177 | Not defined | SSH | 1 |
| Body | 2186 | Not defined | IEEE | 4 |
| Body | 2193 | Not defined | ACM | 5 |
| Body | 2202 | Not defined | SIGSAC | 1 |
| Body | 2202 | Defined again | CCS | 2 |
| Body | 2232 | Not defined | CR | 1 |
| Body | 2249 | Not defined | ACL | 1 |
| Body | 2296 | Not defined | CRC | 1 |

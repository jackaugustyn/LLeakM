# Recenzja ARS-Codex — aktualny artykuł LLeakM

**Rekomendacja: Minor Revision — ograniczone poprawki metod, interpretacji i prezentacji.**

Oceniono [aktualny manuskrypt](inputs/template.tex) i [21-stronicowy PDF](inputs/template.pdf) z 1 listopada 2026 r., dla Electronics / Artificial Intelligence / Special Issue „Trustworthy AI for Large Models and Security Systems”. Artykuł pozostawiono bez zmian.

Główny wkład jest obecnie obroniony: sprawdzalne porównanie renderowania oraz ocena zachowania konkretnego rekonstruktora. Osobne rachunki potwierdziły **φ dla 6600 rekonstrukcji**, wyniki **15/21** porównań modeli, **3/6** kontroli i **10/10** obron po korekcie Holma oraz dopasowanie **600** nowych renderowań. To nie rozstrzyga poprawności wszystkich mechanizmów rekonstruktora — recenzja wykryła dodatkowy problem jego selektora.

## Najważniejsze uwagi

### 1. Ranking kandydatów może uwzględniać PAD po EOS

`weiss_reconstruction.py:271–285` sumuje wyniki przejść także na pozycjach dopełnienia krótszych zakończonych sekwencji. Test na gotowych tensorach wykazał możliwość odwrócenia kolejności kandydatów. **Częstość i wpływ na faktyczną kampanię pozostają nieustalone**, ponieważ nie zapisano wszystkich kandydatów i ich wyników.

R1 klasyfikuje to jako Minor pod warunkiem utrzymania obecnego celu: opisu dokładnie wykonanej implementacji. Należy jawnie opisać regułę i jej ograniczenie. Jeżeli wyniki mają reprezentować ranking prawdopodobieństwa sekwencji do EOS, potrzebny jest najpierw ograniczony audyt inferencji z pełnym zapisem kandydatów. Dopiero on wyznaczy zakres ewentualnych ponownych obliczeń. Nie ma podstaw, by uznać wpływ za zerowy lub automatycznie nakazać powtórzenie wszystkiego.

Źródła: **R1-W1**, [kontrprzykład selektora](phase1_panel/methodology_artifacts/candidate_ranking_check.json).

### 2. `pad_32` daje stałe wejście badanego dekodera

Po obcięciu wejścia T5 różnice długości śladów znikają. W każdym z badanych podzbiorów `pad_32` wejście jest identyczne: audyt objął łącznie **660 rekordów**. W frozen MAP wszystkie **150 par** między modelami przy wspólnym seedzie daje tę samą predykcję.

Dlatego dodatniego wyniku tego konkretnego dekodera nie należy tłumaczyć wykorzystaniem zróżnicowania długości, które do niego nie dotarło. Pełny kanał może tę informację zachować dla innego atakującego. Wystarczy doprecyzowanie wyników i dyskusji na podstawie istniejących zapisów.

Źródła: **R2-W1, DA-N1**, [audyt wejść](phase1_panel/domain_artifacts/pad32_effective_input_audit.json).

### 3. MAP i bootstrap potrzebują pełniejszej specyfikacji

Opisać lokalną dominantę, reguły dla niewidzianych obserwacji, priory, remisy i heurystykę ostatniej grupy batchingu. Oddzielić ziarno głównego bootstrapu od ziaren BLAKE2s komórek i kontrastów pilotów/MAP. Zapisane liczby są zgodne z faktycznym kodem; brakuje wystarczająco dokładnego opisu tego kodu.

Źródła: **R1-W2–W3**. Nie wymagają nowej inferencji.

### 4. Porównanie z Weissem wymaga rozróżnienia miar i zakresów

Przy 27% i około 53% podać, że szczegółowa ocena źródłowa dotyczy pierwszych segmentów i kosinusa embeddingów. Obecny kosinus częstości słów oraz LR@0.5 nie są tym samym wskaźnikiem. Uzupełnić też kontekst treningu rekonstruktora i różnicę między długościami znakowymi a bajtami UTF-8. Dane bibliograficzne Li można zaktualizować do opublikowanej wersji USENIX 2026.

Źródła: **R2-W2–W3** i sprawdzone oryginały trzech najbliższych publikacji.

### 5. Ułatwić rozpoznanie zakresu pracy

Doprecyzować tytuł oraz zebrać różnice protokołów w jednym zestawieniu. Wskazać zamrożoną wersję pakietu danych i sposób dostępu; jest to uwaga o udostępnieniu, nie samodzielna wada naukowa. Nie trzeba dodawać eksperymentu TLS, ocen semantycznych ani pełnego retrainingu, by zamknąć obecne uwagi.

Źródła: **EIC-W1–W3**.

## W stosunku do poprzedniej recenzji

Główne wcześniejsze przeszkody zostały usunięte dla obecnego, ograniczonego zakresu: rekonstrukcje używają zweryfikowanych logów; dwie zdeformowane referencje mają odrębne, sprawdzone porównanie renderowania; limity T5, pokrycie wejść i pełna referencja są jawne. Aktualny wniosek kontrolny odpowiada 3/6 istotnych kontrastów. Zachowano granice dotyczące historycznych ID, wspólnych scenariuszy MAP i publicznej archiwizacji.

Nie jest to automatyczne uznanie całego artykułu za wolny od błędów. Nowa uwaga o selekcji PAD/EOS wymaga osobnego odniesienia, mimo prawidłowych rachunków na zapisanych predykcjach. [Porównanie z poprzednią recenzją](phase2_synthesis/previous_review_comparison.md) dokumentuje zakres zamknięcia wcześniejszych uwag.

## Raporty i dalsze wykorzystanie

| Rola | Ocena w swoim zakresie | Raport |
|---|---|---|
| Journal-Fit | Minor Revision | [EIC](phase1_panel/eic_review.md) |
| Metodologia | Minor Revision | [R1](phase1_panel/methodology_review.md) |
| Dziedzina i literatura | Minor Revision | [R2](phase1_panel/domain_review.md) |
| Perspektywa praktyczna | Accept w zakresie R3 | [R3](phase1_panel/perspective_review.md) |
| Devil’s Advocate | Brak Critical/Major, jedna uwaga Minor | [DA](phase1_panel/da_review.md) |

[Pełna synteza i warunki poprawek](phase2_synthesis/decision_letter.md) oraz [plan uwag w JSON](phase2_synthesis/revision_roadmap.json) zachowują pochodzenie wszystkich ustaleń. Plan nie stanowi decyzji autora o zmianie artykułu.

Jest to **symulowana recenzja ARS-Codex, `NOT_CALIBRATED`**, pięciu ról jednej rodziny modeli. Role pracowały w oddzielnych kontekstach bez przekazywania wzajemnych ocen; syntetyzator zna wcześniejszą historię redakcji. Nie jest to decyzja czasopisma ani dowód niezależności błędów. Aktualnych wymagań MDPI/Special Issue nie potwierdzono z powodu HTTP 403. Sprawdzono źródłowo trzy najbliższe prace; nie certyfikowano całej bibliografii.

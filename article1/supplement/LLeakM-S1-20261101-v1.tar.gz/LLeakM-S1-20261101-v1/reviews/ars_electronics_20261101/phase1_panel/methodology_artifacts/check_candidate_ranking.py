"""No inference: fabricated generation tensors exercise recorded ranking code.
This verifies a reachable implementation behavior, not its prevalence in saved runs.
"""
from pathlib import Path
from types import SimpleNamespace
import sys, json
import torch
from transformers.generation.utils import GenerationMixin
ROOT=Path('/home/paugustynowicz/LLeakM');sys.path.insert(0,str(ROOT))
import weiss_reconstruction as wr
# IDs: 0=PAD/start, 1=EOS, 2=short candidate word, 3=long candidate word.
sequences=torch.tensor([[0,2,1,0,0],[0,3,3,3,1]])
scores=tuple(torch.tensor(x,dtype=torch.float32) for x in [
 [[-float('inf'),-3,3,-3],[-float('inf'),0,0,0]],
 [[-float('inf'),3,-3,-3],[-float('inf'),0,0,0]],
 [[-float('inf'),0,0,0],[-float('inf'),0,0,0]],
 [[-float('inf'),0,0,0],[-float('inf'),0,0,0]],
])
class FakeModel:
 config=SimpleNamespace(vocab_size=4)
 compute_transition_scores=GenerationMixin.compute_transition_scores
 def generate(self,**kwargs): return SimpleNamespace(sequences=sequences,scores=scores)
class FakeTokenizer:
 def decode(self,ids,skip_special_tokens=True):return 'short' if int(ids[1])==2 else 'long'
model=FakeModel();old=wr._prepare_input
try:
 wr._prepare_input=lambda *a,**kw:{}
 actual=wr._sample_and_rank(model,FakeTokenizer(),'cpu','synthetic',samples=2)
finally:wr._prepare_input=old
transition=model.compute_transition_scores(sequences,scores,normalize_logits=True)
valid_lengths=[2,4]
masked=[float(transition[i,:n].sum()) for i,n in enumerate(valid_lengths)]
assert actual[0][0]=='long' and masked[0]>masked[1]
result={'scope':'Synthetic predetermined token arrays only; no model weights loaded, no inference. The currently pinned function is called unchanged apart from stub input tokenization.','sequences':sequences.tolist(),'transition_scores':[[-999 if not torch.isfinite(x) else float(x) for x in row] for row in transition],'nonfinite_sentinel':-999,'actual_rank_order':[x[0] for x in actual],'actual_rank_scores':[None if not torch.isfinite(torch.tensor(x[1])) else x[1] for x in actual],'scores_through_first_EOS_including_EOS':masked,'correct_EOS_mask_rank_order':['short','long'],'observed_saved_run_prevalence':'NOT_ASSESSED: saved records contain selected prediction and encoder inputs; candidate output token IDs and scores are absent.','implementation_pointer':'weiss_reconstruction.py:271-285','library_pointer':'transformers/generation/utils.py:1215-1251; _sample stores scores before forcing PAD for completed sequences at lines3224-3255'}
Path(__file__).with_name('candidate_ranking_check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

"""Read-only domain checks of stored inputs; output only in this review directory."""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import os

os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
EXP = ROOT / "experiment_validation/revalidation_20261031"


def rows(path):
    return [json.loads(line) for line in path.open()]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def pad_audit():
    source = EXP / "secondary/cuda_full/samples.jsonl"
    groups = defaultdict(list)
    for row in rows(source):
        if row["condition"] == "pad_32":
            groups[(row["suite"], row["label"], row["attacker"])].append(row)
    result = []
    for (suite, model, attacker), records in sorted(groups.items()):
        effective = [
            tuple(tuple(x["retained_token_ids"]) for x in r["actual_encoder_inputs"])
            for r in records
        ]
        n = [len(r["observed_lengths"]) for r in records]
        result.append({
            "suite": suite, "model": model, "attacker": attacker,
            "records": len(records), "unique_prompts": len({r["idx"] for r in records}),
            "observed_length_range": [min(n), max(n)],
            "unique_retained_encoder_inputs": len(set(effective)),
            "encoder_calls": sorted(set(len(e) for e in effective)),
            "all_calls_truncated": all(
                x["full_token_count"] > x["max_length"]
                for r in records for x in r["actual_encoder_inputs"]
            ),
            "example_retained_ids": list(effective[0][0]),
            "decoder_seed_count": len({r["decoder_seed"] for r in records}),
        })
    save("pad32_effective_input_audit.json", {
        "source": str(source.relative_to(ROOT)), "source_sha256": sha(source),
        "method": "Group saved retained_token_ids, including every encoder call, within suite/model/attacker.",
        "groups": result,
    })
    print("PAD32", [{k: v for k, v in r.items() if k != "example_retained_ids"} for r in result])


def rendering_audit():
    from transformers import AutoTokenizer

    primary_path = EXP / "inference/cuda_full/samples.jsonl"
    archived = {(r["label"], r["idx"]): r for r in rows(primary_path)}
    base_protocol = json.loads((primary_path.parent / "protocol.json").read_text())
    protocol_fields = ["device", "all_segments", "samples_per_segment",
                       "encoder_and_decoder_max_length", "torch", "transformers",
                       "checkpoints", "checkpoint_file_sha256", "reconstructor_sha256", "precision"]
    result = []
    for short, label, fresh_dir in [
        ("tinyllama", "tinyllama_1_1b", "fresh_tinyllama_cuda"),
        ("phi", "phi_3_5_mini", "fresh_phi_cuda"),
    ]:
        gen_dir = EXP / "fresh_references" / short
        gen_path = gen_dir / "canonical_traces.jsonl"
        proto = json.loads((gen_dir / "protocol.json").read_text())
        tokenizer = AutoTokenizer.from_pretrained(
            proto["model_id"], revision=proto["revision"], local_files_only=True
        )
        decoded_tokens = {}
        gen_rows = rows(gen_path)
        fresh_path = EXP / "inference" / fresh_dir / "samples.jsonl"
        predictions = {r["idx"]: r for r in rows(fresh_path)}
        fresh_protocol = json.loads((fresh_path.parent / "protocol.json").read_text())
        counts = defaultdict(int)
        phi_old, phi_new = [], []
        for g in gen_rows:
            old = archived[(label, g["idx"])]
            new = predictions[g["idx"]]
            legacy_fragments = []
            for token in g["generated_token_ids"]:
                if token not in decoded_tokens:
                    decoded_tokens[token] = tokenizer.decode(
                        [token], skip_special_tokens=False, clean_up_tokenization_spaces=False
                    )
                legacy_fragments.append(decoded_tokens[token])
            legacy = "".join(legacy_fragments)
            legacy_lengths = [len(s.encode("utf-8")) for s in legacy_fragments]
            full = tokenizer.decode(g["generated_token_ids"], skip_special_tokens=False,
                                    clean_up_tokenization_spaces=False)
            old_log = json.loads((ROOT / "logs" / (g["historical_run_id"] + ".json")).read_text())
            counts["legacy_reference_equals_archived"] += legacy == old["reference"]
            counts["legacy_lengths_equal_archived"] += legacy_lengths == old["token_lengths"]
            counts["legacy_fragments_equal_archived"] += legacy_fragments == [s["token_text"] for s in old_log["steps"]]
            counts["full_decode_equals_fresh_reference"] += full == g["reference"] == new["reference"]
            counts["references_identical_after_removing_ASCII_spaces"] += legacy.replace(" ", "") == full.replace(" ", "")
            counts["matched_reconstruction_seeds"] += old["reconstruction_seed"] == new["reconstruction_seed"]
            phi_old.append(old["phi"])
            phi_new.append(new["phi"])
        mean_old = sum(phi_old) / len(phi_old)
        mean_new = sum(phi_new) / len(phi_new)
        result.append({
            "model": label, "n": len(gen_rows), "checks": dict(counts),
            "tokenizer_model_id": proto["model_id"], "tokenizer_revision": proto["revision"],
            "protocol_comparisons": {k: base_protocol.get(k) == fresh_protocol.get(k) for k in protocol_fields},
            "mean_phi_legacy": mean_old, "mean_phi_full": mean_new,
            "mean_phi_joint_difference": mean_new - mean_old,
            "source_sha256": {str(p.relative_to(ROOT)): sha(p) for p in [gen_path, fresh_path]},
        })
    save("matched_rendering_domain_check.json", {
        "source_primary_sha256": sha(primary_path),
        "method": "Independently decode saved victim IDs with pinned local tokenizers; compare old logs, references, lengths, saved decoder seeds and protocol fields. No victim/T5 inference rerun.",
        "scope_limit": "The original victim token IDs are unavailable. Agreement validates the emitted text/length equivalence, not historical checkpoint identity or a decomposition of trace and scoring-reference effects.",
        "models": result,
    })
    print("RENDERING", result)


if __name__ == "__main__":
    pad_audit()
    rendering_audit()
